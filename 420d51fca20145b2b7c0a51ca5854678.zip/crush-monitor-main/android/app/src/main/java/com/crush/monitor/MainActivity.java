package com.crush.monitor;

import android.content.Intent;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(CrushAnalyzerPlugin.class);
    super.onCreate(savedInstanceState);
    handleIntent(getIntent());
  }

  @Override
  public void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    handleIntent(intent);
  }

  /** 接收外部分享的文本（如微信聊天记录） */
  private void handleIntent(Intent intent) {
    if (intent == null) return;
    String action = intent.getAction();
    String type = intent.getType();
    if (Intent.ACTION_SEND.equals(action) && "text/plain".equals(type)) {
      String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
      if (sharedText != null && !sharedText.isEmpty()) {
        // 通道1：冷启动时暂存，等前端挂载后主动拉取
        CrushAnalyzerPlugin.setPendingShare(sharedText);
        // 通道2：App 已运行时直接注入事件
        bridge.getWebView().post(() -> {
          String escaped = sharedText
              .replace("\\", "\\\\")
              .replace("'", "\\'")
              .replace("\n", "\\n")
              .replace("\r", "\\r");
          bridge.eval(
            "window.dispatchEvent(new CustomEvent('app:shared-text', { detail: '" + escaped + "' }));",
            null
          );
        });
      }
    }
  }
}
