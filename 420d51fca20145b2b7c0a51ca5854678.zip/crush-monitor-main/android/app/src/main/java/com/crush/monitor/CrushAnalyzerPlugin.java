package com.crush.monitor;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * 原生层分析通道：在 Android 原生代码中直接请求 TypeSafe API，
 * 避免浏览器 WebView 的 CORS 限制。API Key 只保存在本机。
 */
@CapacitorPlugin(name = "CrushAnalyzer")
public class CrushAnalyzerPlugin extends Plugin {

    private static final String BASE_URL = "https://api.typesafe.ai/v1/systemone";
    private static final String DEFAULT_MODEL = "jev-1.13.0";
    private static final int CONNECT_TIMEOUT_MS = 15000;
    private static final int READ_TIMEOUT_MS = 45000;

    /** 冷启动时暂存外部分享的文本，等待前端拉取 */
    private static volatile String pendingShare = null;

    public static void setPendingShare(String text) {
        pendingShare = text;
    }

    @PluginMethod
    public void getPendingShare(PluginCall call) {
        JSObject ret = new JSObject();
        if (pendingShare != null) {
            ret.put("text", pendingShare);
            pendingShare = null; // 取一次后清空，避免重复导入
        }
        call.resolve(ret);
    }

    @PluginMethod
    public void analyze(PluginCall call) {
        String provider = call.getString("provider", "jev");
        String bodyJson = call.getString("bodyJson");
        String apiKey = call.getString("apiKey");

        if (bodyJson == null || bodyJson.isEmpty()) {
            call.reject("缺少请求内容");
            return;
        }
        if (apiKey == null || apiKey.trim().isEmpty()) {
            call.reject("请先在「聊天设置」里填写对应模型的 API Key");
            return;
        }
        String url = "deepseek".equals(provider)
                ? "https://api.deepseek.com/chat/completions"
                : "https://api.typesafe.ai/v1/systemone";
        final String finalUrl = url;
        final String finalKey = apiKey.trim();

        new Thread(() -> {
            try {
                String response = postJson(finalUrl, bodyJson, finalKey);
                JSObject ret = new JSObject();
                ret.put("result", response);
                call.resolve(ret);
            } catch (Exception e) {
                call.reject(e.getMessage() == null ? "请求失败" : e.getMessage());
            }
        }, "crush-analyze").start();
    }

    private String postJson(String urlStr, String body, String apiKey) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
        conn.setReadTimeout(READ_TIMEOUT_MS);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setRequestProperty("User-Agent", "crush-monitor-android/1.1.1");
        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) {
            try (BufferedReader reader =
                    new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
        }
        conn.disconnect();
        if (code >= 400) {
            throw new Exception("HTTP " + code + ": " + sb);
        }
        return sb.toString();
    }
}
