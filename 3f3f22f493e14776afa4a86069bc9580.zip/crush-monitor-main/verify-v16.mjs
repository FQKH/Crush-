import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "/usr/local/bin/chromium", args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 420, height: 860 } });
await page.goto("http://127.0.0.1:4177/", { waitUntil: "networkidle" });
await page.waitForTimeout(400);

// 1. 导入示例并开始分析（跳过真实 API 调用）
await page.evaluate(() => [...document.querySelectorAll("button")].find(b => b.textContent?.includes("用一段示例试试"))?.click());
await page.waitForTimeout(400);
await page.evaluate(() => [...document.querySelectorAll("button")].find(b => b.textContent?.includes("开始分析"))?.click());
await page.waitForTimeout(500);

// 2. 检查右上角设置按钮是否已删（chat-head 里不应有更多按钮）
const headerBtns = await page.evaluate(() => {
  const head = document.querySelector(".chat-head");
  return head ? [...head.querySelectorAll("button")].map(b => b.getAttribute("aria-label")) : [];
});
console.log("顶部按钮:", JSON.stringify(headerBtns));

// 3. 检查侧栏（不应有设置齿轮）
const railBtns = await page.evaluate(() => {
  const rail = document.querySelector(".chat-rail");
  return rail ? [...rail.querySelectorAll("button")].map(b => b.getAttribute("aria-label")) : [];
});
console.log("侧栏按钮:", JSON.stringify(railBtns));

// 4. 点底部"设置"Tab → 应该出现设置独立页面（不是弹窗）
await page.evaluate(() => {
  const btns = [...document.querySelectorAll(".ios-tabbar button")];
  btns.find(b => b.textContent?.includes("设置"))?.click();
});
await page.waitForTimeout(500);
const settingsPage = await page.evaluate(() => {
  const sp = document.querySelector(".settings-page");
  return {
    hasPage: !!sp,
    rect: sp ? { top: Math.round(sp.getBoundingClientRect().top), bottom: Math.round(sp.getBoundingClientRect().bottom) } : null,
    hasBackdrop: !!document.querySelector(".ios-sheet-backdrop"),
    hasCard: !!document.querySelector(".settings-card"),
    hasSegment: !!document.querySelector(".ios-segment"),
  };
});
console.log("设置页面:", JSON.stringify(settingsPage));
await page.screenshot({ path: "/tmp/v16-settings.png", fullPage: false });

// 5. 切回聊天页
await page.evaluate(() => {
  const btns = [...document.querySelectorAll(".ios-tabbar button")];
  btns.find(b => b.textContent?.includes("聊天"))?.click();
});
await page.waitForTimeout(400);
const chatVisible = await page.evaluate(() => !!document.querySelector(".chat-scroll"));
console.log("切回聊天页:", chatVisible);
await browser.close();
