import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "/usr/local/bin/chromium", args: ["--no-sandbox"] });
const page = await browser.newPage();
await page.goto("http://127.0.0.1:4173/", { waitUntil: "domcontentloaded" });
const result = await page.evaluate(async () => {
  try {
    const res = await fetch("https://api.typesafe.ai/v1/systemone", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer sk-invalid-test" },
      body: JSON.stringify({ state: { relationship: "crush", messages: [] }, questions: { q: { type: "noul", question: "hi" } } }),
    });
    return { corsBlocked: false, status: res.status };
  } catch (e) {
    return { corsBlocked: true, error: String(e) };
  }
});
console.log(JSON.stringify(result));
await browser.close();
