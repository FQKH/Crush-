import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "/usr/local/bin/chromium", args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 420, height: 800 } });
await page.goto("http://127.0.0.1:4175/", { waitUntil: "networkidle" });
await page.waitForTimeout(500);
// 导入示例
await page.evaluate(() => [...document.querySelectorAll("button")].find(b => b.textContent?.includes("用一段示例试试"))?.click());
await page.waitForTimeout(800);
// 点开始分析（不需要真分析，只要看布局）
await page.screenshot({ path: "/tmp/layout-check.png", fullPage: true });
// 检查 message 的 margin
const margins = await page.evaluate(() => {
  const msgs = [...document.querySelectorAll(".message")].slice(0, 4);
  return msgs.map(m => {
    const s = getComputedStyle(m);
    return { marginBottom: s.marginBottom, height: m.offsetHeight };
  });
});
console.log("Message margins:", margins);
await browser.close();
