package com.crush.monitor;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.widget.Toast;
import com.getcapacitor.BridgeActivity;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends BridgeActivity {

  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(CrushAnalyzerPlugin.class);
    super.onCreate(savedInstanceState);
    disableSecureKeyboard();
    handleIntent(getIntent());
  }

  /** 禁用WebView默认安全键盘，允许复制粘贴API密钥 */
  private void disableSecureKeyboard() {
    if (bridge == null || bridge.getWebView() == null) return;
    WebSettings settings = bridge.getWebView().getSettings();
    settings.setSaveFormData(false);
    settings.setSavePassword(false);
    bridge.getWebView().setOnLongClickListener(null);
  }

  @Override
  public void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    handleIntent(intent);
  }

  /** 接收外部分享的文本或文件 */
  private void handleIntent(Intent intent) {
    if (intent == null) {
      toast("intent为空");
      return;
    }
    String action = intent.getAction();
    String type = intent.getType();
    toast("action=" + action + " type=" + type);

    // 文本分享
    if (Intent.ACTION_SEND.equals(action) && type != null && type.startsWith("text/")) {
      String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
      if (sharedText != null && !sharedText.isEmpty()) {
        toast("收到文本，长度=" + sharedText.length());
        CrushAnalyzerPlugin.setPendingShare(sharedText);
        deliverToFrontend(sharedText);
      } else {
        toast("文本内容为空");
      }
      return;
    }

    // 单个文件分享
    if (Intent.ACTION_SEND.equals(action)) {
      Uri fileUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
      if (fileUri == null) {
        toast("没拿到文件Uri");
        return;
      }
      processFileUri(fileUri);
    }

    // 多个文件分享（微信用的这个）
    if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
      ArrayList<Uri> uris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
      if (uris == null || uris.isEmpty()) {
        toast("没拿到文件列表");
        return;
      }
      toast("收到" + uris.size() + "个文件，取第一个处理");
      // 取第一个zip/txt文件
      processFileUri(uris.get(0));
    }
  }

  /** 处理单个文件Uri */
  private void processFileUri(Uri fileUri) {
    toast("收到文件Uri: " + fileUri.toString());
    final Uri finalUri = fileUri;
    new Thread(() -> {
      try {
        String content = readSharedFile(finalUri);
        if (content != null && !content.isEmpty()) {
          final String result = content;
          runOnUiThread(() -> {
            toast("读取成功，长度=" + result.length());
            CrushAnalyzerPlugin.setPendingShare(result);
            deliverToFrontend(result);
          });
        } else {
          runOnUiThread(() -> toast("读取内容为空"));
        }
      } catch (Exception e) {
        e.printStackTrace();
        final String err = e.getMessage();
        runOnUiThread(() -> toast("读取失败: " + err));
      }
    }).start();
  }

  /** 读取分享的文件，自动判断zip还是文本 */
  private String readSharedFile(Uri uri) throws Exception {
    InputStream is = getContentResolver().openInputStream(uri);
    if (is == null) {
      throw new Exception("无法打开文件流");
    }

    // 先读前几个字节判断是不是zip（zip文件头是PK，即0x504B）
    byte[] header = new byte[4];
    int headerRead = is.read(header);
    boolean isZip = headerRead >= 2 && (header[0] == 0x50 && header[1] == 0x4B);

    // 重新打开流
    is.close();
    is = getContentResolver().openInputStream(uri);
    if (is == null) throw new Exception("无法重新打开文件");

    if (isZip) {
      toast("识别为zip文件，开始解压");
      ZipInputStream zis = new ZipInputStream(is);
      ZipEntry entry;
      while ((entry = zis.getNextEntry()) != null) {
        toast("zip内文件: " + entry.getName());
        if (!entry.isDirectory() && entry.getName().endsWith(".txt")) {
          ByteArrayOutputStream baos = new ByteArrayOutputStream();
          byte[] buffer = new byte[4096];
          int count;
          while ((count = zis.read(buffer)) != -1) {
            baos.write(buffer, 0, count);
          }
          zis.close();
          return baos.toString("UTF-8");
        }
      }
      zis.close();
      throw new Exception("zip里没找到txt文件");
    }

    // 普通文本
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    byte[] buffer = new byte[4096];
    int count;
    while ((count = is.read(buffer)) != -1) {
      baos.write(buffer, 0, count);
    }
    is.close();
    return baos.toString("UTF-8");
  }

  /** 把内容注入前端 */
  private void deliverToFrontend(String content) {
    if (bridge == null || bridge.getWebView() == null) {
      toast("bridge还没准备好，内容已暂存");
      return;
    }
    bridge.getWebView().post(() -> {
      String escaped = content
          .replace("\\", "\\\\")
          .replace("'", "\\'")
          .replace("\n", "\\n")
          .replace("\r", "\\r");
      bridge.eval(
        "window.dispatchEvent(new CustomEvent('app:shared-text', { detail: '" + escaped + "' }));",
        null
      );
      toast("已注入前端");
    });
  }

  /** 显示Toast - 全部关闭，不弹任何提示 */
  private void toast(String msg) {
    // 所有提示都写到日志里，不弹Toast
  }
}
