import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.crush.monitor',
  appName: 'Crush好感监控器',
  webDir: 'dist'
};

export default config;
