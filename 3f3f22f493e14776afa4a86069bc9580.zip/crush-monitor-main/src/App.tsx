import { useVirtualizer } from "@tanstack/react-virtual";
import JSZip from "jszip";
import {
  loadConversations,
  saveConversations,
  createConversation,
  type MultiConversations,
  type Conversation,
} from "./storage";
import { INTENTS, topIntents } from "../shared/intents";
import { REPLY_RATINGS, replyRating } from "../shared/ratings";
import { EMOTIONS, topEmotions } from "../shared/labels";
import {
  useEffect,
  useRef,
  useState,
  useCallback,
  type ReactNode,
} from "react";
import {
  Heart,
  MoreHorizontal,
  X,
  ArrowUpRight,
  RotateCcw,
  MessageCircle,
  Settings2,
  Plus,
  ArrowRight,
  Send,
  Check,
} from "lucide-react";
import { parseChat, toMessages, mergeMessages } from "../shared/parser";
import { API_KEY_STORAGE, DEEPSEEK_KEY_STORAGE, OPENAI_KEY_STORAGE, OPENAI_URL_STORAGE, OPENAI_MODEL_STORAGE, HUNYUAN_KEY_STORAGE, QWEN_KEY_STORAGE, GLM_KEY_STORAGE, KIMI_KEY_STORAGE, PROVIDER_STORAGE, REPLY_PROVIDER_STORAGE, PROVIDER_CONFIG, generateReplies, type Provider } from "./analysisClient";
import {
  RUBRIC,
  ACTIONS,
  RELATIONS,
  statusLabel,
  meanQuality,
  type Message,
  type Relation,
  type Parsed,
} from "../shared/types";
import { exampleText } from "../shared/fixtures";
import { useAnalysis } from "./useAnalysis";

function Modal({
  title,
  children,
  close,
}: {
  title: string;
  children: ReactNode;
  close: () => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const old = document.activeElement as HTMLElement;
    ref.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "Tab") {
        const nodes = Array.from(
          ref.current?.querySelectorAll<HTMLElement>(
            "button:not(:disabled),select,textarea,input",
          ) || [],
        );
        if (e.shiftKey && document.activeElement === nodes[0]) {
          e.preventDefault();
          nodes.at(-1)?.focus();
        } else if (!e.shiftKey && document.activeElement === nodes.at(-1)) {
          e.preventDefault();
          nodes[0]?.focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      old?.focus();
    };
  }, []);
  return (
    <div
      className="overlay"
      onMouseDown={(e) => e.target === e.currentTarget && close()}
    >
      <div
        ref={ref}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="modal"
      >
        <header>
          <h2>{title}</h2>
          <button className="icon" aria-label="关闭" onClick={close}>
            <X size={20} />
          </button>
        </header>
        {children}
      </div>
    </div>
  );
}
export default function App() {
  const a = useAnalysis();
  const [messages, setMessages] = useState<Message[]>([]),
    [input, setInput] = useState(""),
    [self, setSelf] = useState(""),
    [other, setOther] = useState("Crush"),
    [relation, setRelation] = useState<Relation>("crush"),
    [knows, setKnows] = useState(false),
    [background, setBackground] = useState(""),
    [fantasyMode, setFantasyMode] = useState(false);
  const [raw, setRaw] = useState(""),
    [parsed, setParsed] = useState<Parsed[]>([]),
    [role, setRole] = useState(""),
    [importing, setImporting] = useState(false),
    [tab, setTab] = useState<"chat" | "settings">("chat"),
    [detail, setDetail] = useState<string | null>(null),
    [notice, setNotice] = useState("");
  const [apiKey, setApiKey] = useState(
    () => localStorage.getItem(API_KEY_STORAGE) ?? "",
  );
  const saveApiKey = (v: string) => {
    setApiKey(v);
    try {
      localStorage.setItem(API_KEY_STORAGE, v.trim());
    } catch {
      /* 存储不可用时忽略 */
    }
  };
  const [provider, setProvider] = useState<Provider>(
    () => (localStorage.getItem(PROVIDER_STORAGE) as Provider) ?? "jev",
  );
  const changeProvider = (p: Provider) => {
    setProvider(p);
    try {
      localStorage.setItem(PROVIDER_STORAGE, p);
    } catch {
      /* ignore */
    }
  };
  // 回复生成模型（全局默认，人物可单独覆盖）
  const [replyProvider, setReplyProvider] = useState<Provider>(
    () => (localStorage.getItem(REPLY_PROVIDER_STORAGE) as Provider) ?? "jev",
  );
  const changeReplyProvider = (p: Provider) => {
    setReplyProvider(p);
    try {
      localStorage.setItem(REPLY_PROVIDER_STORAGE, p);
    } catch {
      /* ignore */
    }
  };
  const [deepseekKey, setDeepseekKey] = useState(
    () => localStorage.getItem(DEEPSEEK_KEY_STORAGE) ?? "",
  );
  const saveDeepseekKey = (v: string) => {
    setDeepseekKey(v);
    try {
      localStorage.setItem(DEEPSEEK_KEY_STORAGE, v.trim());
    } catch {
      /* ignore */
    }
  };
  // OpenAI 兼容配置
  const [openaiKey, setOpenaiKey] = useState(
    () => localStorage.getItem(OPENAI_KEY_STORAGE) ?? "",
  );
  const [openaiUrl, setOpenaiUrl] = useState(
    () => localStorage.getItem(OPENAI_URL_STORAGE) ?? "https://api.openai.com/v1",
  );
  const [openaiModel, setOpenaiModel] = useState(
    () => localStorage.getItem(OPENAI_MODEL_STORAGE) ?? "gpt-4o-mini",
  );
  const saveOpenaiKey = (v: string) => {
    setOpenaiKey(v);
    try { localStorage.setItem(OPENAI_KEY_STORAGE, v.trim()); } catch {}
  };
  const saveOpenaiUrl = (v: string) => {
    setOpenaiUrl(v);
    try { localStorage.setItem(OPENAI_URL_STORAGE, v.trim()); } catch {}
  };
  const saveOpenaiModel = (v: string) => {
    setOpenaiModel(v);
    try { localStorage.setItem(OPENAI_MODEL_STORAGE, v.trim()); } catch {}
  };
  // 其他模型配置
  const [hunyuanKey, setHunyuanKey] = useState(() => localStorage.getItem(HUNYUAN_KEY_STORAGE) ?? "");
  const [qwenKey, setQwenKey] = useState(() => localStorage.getItem(QWEN_KEY_STORAGE) ?? "");
  const [glmKey, setGlmKey] = useState(() => localStorage.getItem(GLM_KEY_STORAGE) ?? "");
  const [kimiKey, setKimiKey] = useState(() => localStorage.getItem(KIMI_KEY_STORAGE) ?? "");
  const saveHunyuanKey = (v: string) => { setHunyuanKey(v); try { localStorage.setItem(HUNYUAN_KEY_STORAGE, v.trim()); } catch {} };
  const saveQwenKey = (v: string) => { setQwenKey(v); try { localStorage.setItem(QWEN_KEY_STORAGE, v.trim()); } catch {} };
  const saveGlmKey = (v: string) => { setGlmKey(v); try { localStorage.setItem(GLM_KEY_STORAGE, v.trim()); } catch {} };
  const saveKimiKey = (v: string) => { setKimiKey(v); try { localStorage.setItem(KIMI_KEY_STORAGE, v.trim()); } catch {} };
  const [showModelPicker, setShowModelPicker] = useState(false);
  const [showReplyModelPicker, setShowReplyModelPicker] = useState(false);
  const [showPersonSettings, setShowPersonSettings] = useState(false);
  // 主题设置
  const [themeColor, setThemeColor] = useState(
    () => localStorage.getItem("crush_theme_color") ?? "#ff6b9d",
  );
  const [bgImage, setBgImage] = useState(
    () => localStorage.getItem("crush_bg_image") ?? "",
  );
  const fileInputRef = useRef<HTMLInputElement>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);

  // 运行日志
  interface LogEntry {
    time: string;
    type: "info" | "error";
    message: string;
  }
  const [logs, setLogs] = useState<LogEntry[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("crush_logs") ?? "[]");
    } catch {
      return [];
    }
  });
  const [showErrorOnly, setShowErrorOnly] = useState(false);

  // 首次启动弹窗
  const [showWelcome, setShowWelcome] = useState(
    () => !localStorage.getItem("crush_welcomed_v2"),
  );
  const [countdown, setCountdown] = useState(3);

  useEffect(() => {
    if (showWelcome && countdown > 0) {
      const timer = setTimeout(() => setCountdown(c => c - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [showWelcome, countdown]);

  const closeWelcome = () => {
    if (countdown > 0) return;
    localStorage.setItem("crush_welcomed_v2", "1");
    setShowWelcome(false);
  };

  const addLog = (message: string, type: "info" | "error" = "info") => {
    const entry: LogEntry = {
      time: new Date().toLocaleTimeString(),
      type,
      message,
    };
    setLogs(prev => {
      const newLogs = [...prev, entry].slice(-100);
      localStorage.setItem("crush_logs", JSON.stringify(newLogs));
      return newLogs;
    });
  };

  // 推荐回复
  const [replies, setReplies] = useState<string[]>([]);
  const [showReplies, setShowReplies] = useState(false);
  const [repliesLoading, setRepliesLoading] = useState(false);
  const [recentCount, setRecentCount] = useState(20);

  // 应用主题
  useEffect(() => {
    document.documentElement.style.setProperty("--theme-color", themeColor);
    document.documentElement.style.setProperty("--accent", themeColor);
    if (bgImage) {
      document.body.style.backgroundImage = `url(${bgImage})`;
      document.body.style.backgroundSize = "cover";
      document.body.style.backgroundPosition = "center";
      document.body.style.backgroundAttachment = "fixed";
    } else {
      document.body.style.backgroundImage = "";
    }
  }, [themeColor, bgImage]);

  // 错误自动写到日志
  useEffect(() => {
    if (a.error) {
      addLog(a.error, "error");
    }
  }, [a.error]);

  // 通知信息自动写到日志
  useEffect(() => {
    if (notice) {
      addLog(notice, "info");
    }
  }, [notice]);

  // 上传背景图
  const handleBgUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string;
      setBgImage(dataUrl);
      localStorage.setItem("crush_bg_image", dataUrl);
      setNotice("背景图已设置");
      setTimeout(() => setNotice(""), 2000);
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  // 生成推荐回复
  const handleGenerateReplies = async () => {
    if (!messages.length) return;
    setRepliesLoading(true);
    try {
      const result = await generateReplies(messages, RELATIONS[relation], background, recentCount);
      setReplies(result);
      setShowReplies(true);
    } catch (err: any) {
      setNotice(err.message || "生成失败，请重试");
    } finally {
      setRepliesLoading(false);
    }
  };

  // 分析完成后自动生成推荐回复
  const prevStatus = useRef(a.status);
  useEffect(() => {
    if (prevStatus.current === "loading" && a.status === "complete" && messages.length > 0 && !fantasyMode) {
      // 延迟一点，等分析结果渲染完
      const timer = setTimeout(() => {
        handleGenerateReplies();
      }, 500);
      return () => clearTimeout(timer);
    }
    prevStatus.current = a.status;
  }, [a.status, messages.length, fantasyMode]);

  // 复制回复
  const copyReply = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setNotice("已复制到剪贴板");
      setTimeout(() => setNotice(""), 2000);
    }).catch(() => {
      // 降级方案
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      setNotice("已复制到剪贴板");
      setTimeout(() => setNotice(""), 2000);
    });
  };

  // 导入文件
  const handleFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // 只允许txt和zip文件
    const ext = file.name.split(".").pop()?.toLowerCase();
    if (ext !== "txt" && ext !== "zip") {
      setNotice("番茄不允许你们导入不相干的内容");
      e.target.value = "";
      return;
    }
    try {
      let text = "";
      if (ext === "zip") {
        // 解压zip，找里面的txt文件
        const zip = await JSZip.loadAsync(file);
        const files = Object.values(zip.files);
        const txtFile = files.find(f => f.name.endsWith(".txt"));
        if (!txtFile) {
          setNotice("压缩包里没找到聊天记录文件");
          e.target.value = "";
          return;
        }
        text = await txtFile.async("string");
      } else {
        // txt文件直接读取
        const reader = new FileReader();
        text = await new Promise((resolve, reject) => {
          reader.onload = (ev) => resolve(ev.target?.result as string);
          reader.onerror = reject;
          reader.readAsText(file);
        });
      }
      if (text.trim()) {
        setInput(text);
        prepare(text);
      }
    } catch (err) {
      setNotice("文件读取失败，请重试");
    }
    e.target.value = "";
  };
  const [overlap, setOverlap] = useState<Message[] | null>(null);
  const [ready, setReady] = useState(false),
    [storageError, setStorageError] = useState("");

  // 多会话管理
  const [multi, setMulti] = useState<MultiConversations | null>(null);
  const [showNewConv, setShowNewConv] = useState(false);
  const [newConvName, setNewConvName] = useState("");
  const [showConvMenu, setShowConvMenu] = useState<string | null>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const virtual = useVirtualizer({
    count: messages.length,
    getScrollElement: () => scroller.current,
    estimateSize: () => 150,
    getItemKey: useCallback((i: number) => messages[i].id, [messages]),
    overscan: 8,
    anchorTo: "end",
    followOnAppend: true,
    scrollEndThreshold: 100,
  });
  useEffect(() => {
    let live = true;
    loadConversations()
      .then((data) => {
        if (!live) return;
        setMulti(data);
        const active = data.conversations[data.activeId];
        if (active) {
          setMessages(active.messages);
          setSelf(active.self);
          setOther(active.other);
          setRelation(active.relation);
          setKnows(active.knowsYourFeelings ?? false);
          setBackground(active.background ?? "");
          setFantasyMode(active.fantasyMode ?? false);
          // 恢复这个人物的模型配置（如果有的话，没有就用全局默认）
          if (active.analysisProvider) setProvider(active.analysisProvider as Provider);
          if (active.replyProvider) setReplyProvider(active.replyProvider as Provider);
          // 恢复分析结果
          a.restore({
            schema: 1,
            rubric: active.rubric,
            messages: active.messages,
            self: active.self,
            other: active.other,
            relation: active.relation,
            lines: active.lines,
            events: active.events,
            overview: active.overview,
            trend: active.trend,
            analyzedCount: active.analyzedCount,
            completed: active.completed,
          });
          lastAnalyzedCount.current = active.analyzedCount;
        }
        setReady(true);
      })
      .catch(() => {
        if (live) {
          setStorageError(
            "本机记录读取失败，请检查浏览器存储权限。为避免覆盖旧记录，暂不自动保存。",
          );
          setReady(true);
        }
      });
    return () => {
      live = false;
    };
  }, []);

  // 接收微信等外部分享的聊天记录文本，自动导入
  useEffect(() => {
    const onShared = (e: Event) => {
      const text = (e as CustomEvent<string>).detail;
      if (typeof text === "string" && text.trim()) {
        setInput(text);
        prepare(text);
        setNotice("已导入分享的聊天记录，开始分析");
      }
    };
    // 错误事件
    const onShareError = (e: Event) => {
      const msg = (e as CustomEvent<string>).detail;
      if (msg) setNotice(msg);
    };
    window.addEventListener("app:shared-text", onShared);
    window.addEventListener("app:share-error", onShareError);

    // 冷启动场景：分享打开 App 时，主动拉取，带重试（等zip解压）
    const w = window as unknown as {
      Capacitor?: {
        isNativePlatform?: () => boolean;
        Plugins?: {
          CrushAnalyzer?: {
            getPendingShare: () => Promise<{ text?: string }>;
          };
        };
      };
    };
    if (w.Capacitor?.isNativePlatform?.() && w.Capacitor.Plugins?.CrushAnalyzer) {
      const plugin = w.Capacitor.Plugins.CrushAnalyzer;
      // 重试拉取：0.5s、1.5s、3s，确保等zip解压完成
      const delays = [500, 1000, 1500];
      delays.forEach((delay) => {
        setTimeout(() => {
          plugin.getPendingShare().then((r) => {
            if (r?.text?.trim()) {
              setInput(r.text);
              prepare(r.text);
              setNotice("已导入分享的聊天记录，开始分析");
            }
          });
        }, delay);
      });
    }
    return () => {
      window.removeEventListener("app:shared-text", onShared);
      window.removeEventListener("app:share-error", onShareError);
    };
  }, []);
  const pendingSave = useRef<MultiConversations | null>(null),
    saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null),
    lastSavedMessages = useRef<Message[] | null>(null),
    lastAnalyzedCount = useRef(0);

  /** 把当前状态同步到 multi 并保存 */
  const syncAndSave = (data?: MultiConversations) => {
    if (!multi && !data) return;
    const target = data ?? multi!;
    const activeId = target.activeId;
    const conv = target.conversations[activeId];
    if (conv) {
      conv.messages = messages;
      conv.self = self;
      conv.other = other;
      conv.relation = relation;
      conv.knowsYourFeelings = knows;
      conv.background = background;
      conv.fantasyMode = fantasyMode;
      // 保存这个人物的模型配置
      conv.analysisProvider = provider;
      conv.replyProvider = replyProvider;
      conv.rubric = RUBRIC;
      conv.lines = a.lines;
      conv.events = a.events;
      conv.overview = a.overview;
      conv.trend = a.trend;
      conv.analyzedCount = a.analyzedCount;
      conv.completed = a.status === "complete";
    }
    pendingSave.current = { ...target, conversations: { ...target.conversations } };
  };

  const flushSave = () => {
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = null;
    if (!pendingSave.current) return;
    void saveConversations(pendingSave.current).catch(() =>
      setStorageError(
        "本机保存失败，可能存储空间不足。当前页面仍可使用，请勿刷新以免丢失未保存记录。",
      ),
    );
  };

  /** 切换会话：保存当前会话，加载目标会话 */
  const switchConversation = (convId: string) => {
    if (!multi || convId === multi.activeId) return;
    // 先保存当前会话
    syncAndSave();
    flushSave();
    // 加载目标会话
    const target = multi.conversations[convId];
    if (!target) return;
    setMulti({ ...multi, activeId: convId });
    setMessages(target.messages);
    setSelf(target.self);
    setOther(target.other);
    setRelation(target.relation);
    setKnows(target.knowsYourFeelings ?? false);
    setBackground(target.background ?? "");
    setFantasyMode(target.fantasyMode ?? false);
    a.restore({
      schema: 1,
      rubric: target.rubric,
      messages: target.messages,
      self: target.self,
      other: target.other,
      relation: target.relation,
      lines: target.lines,
      events: target.events,
      overview: target.overview,
      trend: target.trend,
      analyzedCount: target.analyzedCount,
      completed: target.completed,
    });
    lastAnalyzedCount.current = target.analyzedCount;
    setTab("chat");
    setNotice(`已切换到「${target.name}」`);
  };

  /** 新建会话 */
  const addConversation = () => {
    const name = newConvName.trim();
    if (!name || !multi) return;
    // 保存当前会话
    syncAndSave();
    flushSave();
    // 创建新会话
    const conv = createConversation(name, "crush");
    const newMulti: MultiConversations = {
      ...multi,
      activeId: conv.id,
      conversations: { ...multi.conversations, [conv.id]: conv },
    };
    setMulti(newMulti);
    // 清空当前状态
    setMessages([]);
    setSelf("");
    setOther(name);
    setRelation("crush");
    setKnows(false);
    setBackground("");
    setFantasyMode(false);
    a.reset();
    lastAnalyzedCount.current = 0;
    setNewConvName("");
    setShowNewConv(false);
    setTab("chat");
    setNotice(`已创建新会话「${name}」`);
  };

  /** 删除会话 */
  const deleteConversation = (convId: string) => {
    if (!multi) return;
    const conv = multi.conversations[convId];
    if (!conv) return;
    const newConvs = { ...multi.conversations };
    delete newConvs[convId];
    // 如果删的是当前活跃会话，切换到第一个
    let newActiveId = multi.activeId;
    if (convId === multi.activeId) {
      const ids = Object.keys(newConvs);
      if (ids.length === 0) {
        // 没有会话了，创建一个新的
        const newConv = createConversation("Crush", "crush");
        newConvs[newConv.id] = newConv;
        newActiveId = newConv.id;
      } else {
        newActiveId = ids[0];
      }
    }
    const newMulti: MultiConversations = {
      schema: 2,
      activeId: newActiveId,
      conversations: newConvs,
    };
    setMulti(newMulti);
    // 如果切换了活跃会话，加载它
    if (newActiveId !== convId) {
      const target = newConvs[newActiveId];
      setMessages(target.messages);
      setSelf(target.self);
      setOther(target.other);
      setRelation(target.relation);
      a.restore({
        schema: 1,
        rubric: target.rubric,
        messages: target.messages,
        self: target.self,
        other: target.other,
        relation: target.relation,
        lines: target.lines,
        events: target.events,
        overview: target.overview,
        trend: target.trend,
        analyzedCount: target.analyzedCount,
        completed: target.completed,
      });
      lastAnalyzedCount.current = target.analyzedCount;
    }
    setShowConvMenu(null);
    setNotice(`已删除会话「${conv.name}」`);
  };

  useEffect(() => {
    if (!ready || storageError) return;
    syncAndSave();
    if (lastSavedMessages.current !== messages || a.status !== "loading" || lastAnalyzedCount.current !== a.analyzedCount) {
      lastSavedMessages.current = messages;
      lastAnalyzedCount.current = a.analyzedCount;
      flushSave();
    } else if (!saveTimer.current)
      saveTimer.current = setTimeout(flushSave, 250);
  }, [
    ready,
    messages,
    self,
    other,
    relation,
    a.lines,
    a.events,
    a.overview,
    a.trend,
    a.analyzedCount,
    a.status,
  ]);
  useEffect(() => {
    const flush = () => {
      if (saveTimer.current) flushSave();
    };
    window.addEventListener("pagehide", flush);
    document.addEventListener("visibilitychange", flush);
    return () => {
      window.removeEventListener("pagehide", flush);
      document.removeEventListener("visibilitychange", flush);
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, []);
  const stay = useRef(true);
  useEffect(() => {
    if (messages.length && stay.current)
      virtual.scrollToIndex(messages.length - 1, { align: "end" });
  }, [messages.length]);
  const busy = a.status === "loading",
    ov = a.overview,
    value = ov?.affinity.value,
    quality = meanQuality(messages, a.lines);
  const last = a.trend.at(-1),
    previous = a.trend.at(-2);
  const delta =
    a.status === "complete" && last?.value != null && previous?.value != null
      ? last.value - previous.value
      : null;
  function start(ms: Message[]) {
    setMessages(ms);
    setInput("");
    a.run(ms, relation, background, knows, fantasyMode);
  }
  function add(ms: Message[], mode: "auto" | "append" | "skip" = "auto") {
    const m = mergeMessages(messages, ms, mode);
    if (m.ambiguous) {
      setOverlap(ms);
      return;
    }
    if (!m.added) {
      setNotice("没有新增消息，这段已经分析过了。");
      setInput("");
      return;
    }
    setNotice("");
    start(m.messages);
  }
  function prepare(text: string) {
    if (!text.trim()) return;
    if (text.length > 250000) {
      setNotice("这次粘贴超过25万字符，请分几次追加；历史记录不会被截断。");
      return;
    }
    const p = parseChat(text);
    const names = [...new Set(p.messages.map((x) => x.speaker))];
    if (
      messages.length &&
      self &&
      !p.warnings.length &&
      names.every((n) => n === self || n === other)
    ) {
      add(toMessages(p.messages, self));
      return;
    }
    setRaw(text);
    setParsed(p.messages);
    setRole(names.includes(self) ? self : names.includes("我") ? "我" : "");
    setImporting(true);
  }
  function confirmImport() {
    const names = [...new Set(parsed.map((x) => x.speaker))];
    setSelf(role);
    setOther(names.find((n) => n !== role) || "Crush");
    setImporting(false);
    add(toMessages(parsed, role));
  }
  function clear() {
    a.reset();
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = null;
    // 清空当前会话的聊天数据，保留会话本身
    if (multi) {
      const conv = multi.conversations[multi.activeId];
      if (conv) {
        conv.messages = [];
        conv.self = "";
        conv.relation = "crush";
        conv.lines = {};
        conv.events = {};
        conv.overview = null;
        conv.trend = [];
        conv.analyzedCount = 0;
        conv.completed = false;
        pendingSave.current = { ...multi, conversations: { ...multi.conversations } };
      }
    }
    flushSave();
    setMessages([]);
    setInput("");
    setSelf("");
    setOther(multi?.conversations[multi.activeId]?.name || "Crush");
    setRelation("crush");
    setNotice("");
    setTab("chat");
    setDetail(null);
  }
  const names = [...new Set(parsed.map((x) => x.speaker))];
  const chosen = messages.find((m) => m.id === detail),
    result = detail ? a.lines[detail] : undefined;
  return (
    <main className="app">
      <div className="workspace">
        <section className="wechat" aria-label="微信聊天">
          <nav className="chat-rail" aria-label="聊天工具">
            <div className="rail-avatar">
              {self && self !== "__self_absent__" ? self.slice(0, 1) : "我"}
            </div>
            <button
              className="rail-active"
              aria-label="滚动到最新聊天"
              onClick={() => {
                stay.current = true;
                if (messages.length)
                  virtual.scrollToIndex(messages.length - 1, { align: "end" });
              }}
            >
              <MessageCircle size={23} />
            </button>
          </nav>
          {/* 多会话标签栏 */}
          {multi && (
            <div className="conv-tabs">
              <div className="conv-tabs-scroll">
                {Object.values(multi.conversations).map((conv) => (
                  <button
                    key={conv.id}
                    className={`conv-tab ${conv.id === multi.activeId ? "active" : ""}`}
                    onClick={() => switchConversation(conv.id)}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      setShowConvMenu(conv.id);
                    }}
                  >
                    {conv.name}
                  </button>
                ))}
                <button
                  className="conv-tab conv-tab-add"
                  onClick={() => setShowNewConv(true)}
                >
                  <Plus size={16} />
                </button>
              </div>
              <button
                className="conv-affinity"
                onClick={() => setDetail("overview")}
                aria-label="查看好感度详情"
              >
                <span className="conv-affinity-label">好感度</span>
                <strong key={fantasyMode ? "fantasy100" : value} className="conv-affinity-number">
                  {fantasyMode ? 100 : (value ?? "—")}
                </strong>
              </button>
              {/* 人物设置按钮，常驻右上角 */}
              <button
                onClick={() => setShowPersonSettings(true)}
                style={{
                  background: "none",
                  border: "none",
                  fontSize: 12,
                  color: "#666",
                  padding: "4px 8px",
                  cursor: "pointer",
                }}
                aria-label="人物设置"
              >
                ⚙
              </button>
            </div>
          )}

          <div
            ref={scroller}
            className="chat-scroll"
            onScroll={(e) => {
              const el = e.currentTarget;
              stay.current =
                el.scrollHeight - el.scrollTop - el.clientHeight < 100;
            }}
          >
            {/* 聊天对象名+关系，直接放在聊天内容顶部，不占额外行高 */}
            <div className="chat-mini-title">
              <h3>{messages.length ? other : "微信聊天"}</h3>
              <span>{RELATIONS[relation]}</span>
            </div>
            {!messages.length ? (
              <div className="empty">
                <h2>粘贴聊天记录</h2>
                <p>支持微信、QQ 复制记录及 WhatsApp 文本导出</p>
                <button
                  className="text-button"
                  onClick={() => prepare(exampleText(0))}
                >
                  用一段示例试试 <ArrowUpRight size={16} />
                </button>
              </div>
            ) : (
              <div
                style={{
                  height: virtual.getTotalSize(),
                  position: "relative",
                  width: "100%",
                }}
              >
                {virtual.getVirtualItems().map((row) => {
                  const i = row.index,
                    m = messages[i];
                  const r = a.lines[m.id];

                  return (
                    <div
                      key={m.id}
                      data-index={row.index}
                      ref={virtual.measureElement}
                      style={{
                        position: "absolute",
                        top: 0,
                        left: 0,
                        width: "100%",
                        transform: `translateY(${row.start}px)`,
                      }}
                      id={`message-${m.id}`}
                      className={`message ${m.sender}`}
                    >
                      {(i === 0 || m.timestamp !== messages[i - 1].timestamp) &&
                        m.timestamp && (
                          <div className="timestamp">
                            {m.timestamp.replace(/^\d{4}年/, "")}
                          </div>
                        )}
                      <div className="message-row">
                        <div
                          className={`avatar ${m.sender === "self" ? "mine" : ""}`}
                        >
                          {(m.sender === "self" ? self : other).slice(0, 1)}
                        </div>
                        <div className="message-content">
                          <div className="bubble">{m.text}</div>
                          {m.kind === "text" && (
                            <div className={`message-tags ${m.sender}`}>
                              {r?.skipped ? (
                                <span className="pending-tag">{r.skipped}</span>
                              ) : m.sender === "other" ? (
                                <>
                                  <div className="analysis-row emotion-row">
                                    <span className="analysis-row-label">
                                      情绪
                                    </span>
                                    {r?.emotions ? (
                                      topEmotions(r.emotions).map((emotion) => (
                                        <button
                                          key={emotion.key}
                                          className={`emotion-tag emotion-${emotion.key}`}
                                          onClick={() => setDetail(m.id)}
                                          aria-label={`${emotion.label} ${emotion.percent}，查看情绪分析：${m.text}`}
                                        >
                                          <span>{emotion.label}</span>
                                          <b>{emotion.percent}</b>
                                        </button>
                                      ))
                                    ) : (
                                      <button
                                        className="pending-tag"
                                        disabled={busy}
                                        onClick={() =>
                                          a.run(messages, relation, background, knows, fantasyMode)
                                        }
                                      >
                                        {busy ? "分析中" : "分析情绪"}
                                      </button>
                                    )}
                                  </div>
                                  <div className="analysis-row intent-row">
                                    <span className="analysis-row-label">
                                      意图
                                    </span>
                                    {r?.intents ? (
                                      topIntents(r.intents).map((intent) => (
                                        <button
                                          key={intent.key}
                                          className="intent-tag"
                                          onClick={() => setDetail(m.id)}
                                          aria-label={`${intent.label} ${intent.percent}，查看意图分析：${m.text}`}
                                        >
                                          <span>{intent.label}</span>
                                          <b>{intent.percent}</b>
                                        </button>
                                      ))
                                    ) : (
                                      <button
                                        className="pending-tag"
                                        disabled={busy}
                                        onClick={() =>
                                          a.run(messages, relation, background, knows, fantasyMode)
                                        }
                                      >
                                        {busy ? "分析中" : "分析意图"}
                                      </button>
                                    )}
                                  </div>
                                </>
                              ) : r ? (
                                <button
                                  className="reply-tag"
                                  onClick={() => setDetail(m.id)}
                                  aria-label={`查看回复评价：${m.text}`}
                                >
                                  <span>回复评级：</span>
                                  <b>
                                    {replyRating(r.score.value)?.label ??
                                      "待判断"}
                                  </b>
                                </button>
                              ) : (
                                <button
                                  className="pending-tag"
                                  disabled={busy}
                                  onClick={() => a.run(messages, relation, background, knows, fantasyMode)}
                                >
                                  {busy ? "分析中" : "评价回复"}
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          <div className="chat-insights">
            <button
              className="reply-summary"
              onClick={() => setDetail("performance")}
            >
              <span>我的发挥</span>
              <strong>{replyRating(quality)?.label ?? "—"}</strong>
              {quality != null && <span>{quality}分</span>}
            </button>
            <span className="insight-divider" />
            <button
              className="action-summary"
              onClick={() => setDetail("action")}
            >
              <span>下一步</span>
              <strong>{ov ? ACTIONS[ov.action]?.label : "等你导入聊天"}</strong>
              <ArrowRight size={14} />
            </button>
          </div>
          <div className="composer">
            <div className="input-row">
              <textarea
                aria-label="粘贴聊天记录"
                disabled={!ready}
                placeholder={
                  messages.length
                    ? "粘贴新的聊天，自动合并重复记录"
                    : "在这里粘贴聊天记录…"
                }
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onPaste={(e) => {
                  const t = e.clipboardData.getData("text");
                  if (t.trim()) {
                    e.preventDefault();
                    setInput(t);
                    prepare(t);
                  }
                }}
                onKeyDown={(e) => {
                  if ((e.metaKey || e.ctrlKey) && e.key === "Enter")
                    prepare(input);
                }}
              />
              <div className="input-actions">
                <button
                  className="circle-btn"
                  onClick={() => fileInputRef.current?.click()}
                  title="导入文件"
                >
                  <Plus size={20} />
                </button>
                <button
                  className="circle-btn"
                  onClick={handleGenerateReplies}
                  disabled={repliesLoading || !messages.length}
                  title="推荐回复"
                >
                  {repliesLoading ? "..." : "回复"}
                </button>
              </div>
            </div>
            <div className="composer-bottom">
              <div className="composer-feedback">
                <span role="status" style={{ display: "none" }}>{storageError || notice}</span>{" "}
                <div className="analysis-status" aria-live="polite">
                  {busy ? (
                    <>
                      <span className="working" />
                      正在分析 {a.progress.done}/{a.progress.total}
                      <button onClick={a.cancel}>停止</button>
                    </>
                  ) : a.status === "error" ? (
                    <span>分析未完成</span>
                  ) : a.status === "complete" ? (
                    <span className="completed">
                      <Check size={14} />
                      分析完成
                    </span>
                  ) : messages.length ? (
                    <span>分析已暂停</span>
                  ) : null}
                </div>
                {/* 报错不显示在屏幕上，全部写到日志里 */}
                {a.error && null}
              </div>
              {/* 分析聊天按钮删掉了，粘贴后自动分析 */}
              {/* 隐藏的文件选择器 */}
              <input
                ref={fileInputRef}
                type="file"
                accept=".txt,.zip"
                style={{ display: "none" }}
                onChange={handleFileImport}
              />
            </div>
          </div>
        </section>
      </div>
      {importing && (
        <Modal title="确认聊天里的你" close={() => setImporting(false)}>
          <div className="role-options">
            {names
              .filter((n) => n !== "未分配")
              .map((n) => (
                <button
                  className={role === n ? "selected" : ""}
                  key={n}
                  onClick={() => setRole(n)}
                >
                  {n}
                </button>
              ))}
            {names.length === 1 && (
              <button
                className={role === "__self_absent__" ? "selected" : ""}
                onClick={() => setRole("__self_absent__")}
              >
                这些都是对方的话
              </button>
            )}
          </div>
          <label className="field">
            识别到 {parsed.length} 条聊天
            <textarea
              value={raw}
              onChange={(e) => {
                setRaw(e.target.value);
                setParsed(parseChat(e.target.value).messages);
              }}
            />
          </label>
          {(names.length > 2 || names.includes("未分配")) && (
            <p className="error">
              请保留两个人的聊天，可改成「我：内容」「对方：内容」。
            </p>
          )}
          <button
            className="primary"
            disabled={
              !role ||
              !parsed.length ||
              names.length > 2 ||
              names.includes("未分配") ||
              (!names.includes(role) && role !== "__self_absent__")
            }
            onClick={confirmImport}
          >
            开始分析
          </button>
        </Modal>
      )}
      {tab === "settings" && (
        <section className="settings-page" aria-label="设置">
          <header className="settings-page-head">
            <h2>设置</h2>
          </header>
          <div className="settings-card">
          <label className="field">
            分析模型
            <button
              className="ios-picker-button"
              onClick={() => setShowModelPicker(true)}
            >
              <span>{PROVIDER_CONFIG[provider].name}</span>
              <span className="chevron">›</span>
            </button>
          </label>

          <label className="field">
            回复生成模型
            <button
              className="ios-picker-button"
              onClick={() => setShowReplyModelPicker(true)}
            >
              <span>{PROVIDER_CONFIG[replyProvider].name}</span>
              <span className="chevron">›</span>
            </button>
          </label>
          <p className="hint">
            分析模型用来解读聊天、算好感度；回复模型用来生成推荐回复，可以选不同的。
          </p>

          {/* 分析模型的Key */}
          {provider === "jev" && (
            <>
              <label className="field">
                分析模型 - TypeSafe API Key
                <input
                  type="text"
                  className="masked-input"
                  value={apiKey}
                  placeholder="粘贴你的 TypeSafe API Key"
                  onChange={(e) => saveApiKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <p className="hint">
                {apiKey.trim()
                  ? "已保存到本机，分析时直接使用"
                  : "需要去 console.typesafe.ai 申请 Key。"}
              </p>
            </>
          )}

          {provider === "deepseek" && (
            <>
              <label className="field">
                分析模型 - DeepSeek API Key
                <input
                  type="text"
                  className="masked-input"
                  value={deepseekKey}
                  placeholder="粘贴你的 DeepSeek API Key"
                  onChange={(e) => saveDeepseekKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <p className="hint">
                {deepseekKey.trim()
                  ? "已保存到本机，分析时直接使用"
                  : "需要去 platform.deepseek.com 申请 Key。"}
              </p>
            </>
          )}

          {/* 回复模型的Key（如果和分析模型不一样，单独显示） */}
          {replyProvider === "jev" && provider !== "jev" && (
            <>
              <label className="field">
                回复模型 - TypeSafe API Key
                <input
                  type="text"
                  className="masked-input"
                  value={apiKey}
                  placeholder="粘贴你的 TypeSafe API Key"
                  onChange={(e) => saveApiKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <p className="hint">给回复生成用的 TypeSafe Key</p>
            </>
          )}

          {replyProvider === "deepseek" && provider !== "deepseek" && (
            <>
              <label className="field">
                回复模型 - DeepSeek API Key
                <input
                  type="text"
                  className="masked-input"
                  value={deepseekKey}
                  placeholder="粘贴你的 DeepSeek API Key"
                  onChange={(e) => saveDeepseekKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <p className="hint">给回复生成用的 DeepSeek Key</p>
            </>
          )}

          {/* 回复模型是OpenAI系（和分析模型不同时单独显示） */}
          {replyProvider === "openai" && provider !== "openai" && (
            <>
              <label className="field">
                回复模型 - OpenAI API Key
                <input
                  type="text"
                  className="masked-input"
                  value={openaiKey}
                  placeholder="粘贴你的 OpenAI API Key"
                  onChange={(e) => saveOpenaiKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <p className="hint">给回复生成用的 OpenAI Key</p>
            </>
          )}

          {replyProvider === "hunyuan" && provider !== "hunyuan" && (
            <>
              <label className="field">
                回复模型 - 混元 API Key
                <input
                  type="text"
                  className="masked-input"
                  value={hunyuanKey}
                  placeholder="粘贴你的 混元 API Key"
                  onChange={(e) => saveHunyuanKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <p className="hint">给回复生成用的 混元 Key</p>
            </>
          )}

          {replyProvider === "qwen" && provider !== "qwen" && (
            <>
              <label className="field">
                回复模型 - 通义千问 API Key
                <input
                  type="text"
                  className="masked-input"
                  value={qwenKey}
                  placeholder="粘贴你的 通义千问 API Key"
                  onChange={(e) => saveQwenKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <p className="hint">给回复生成用的 通义千问 Key</p>
            </>
          )}

          {replyProvider === "glm" && provider !== "glm" && (
            <>
              <label className="field">
                回复模型 - 智谱清言 API Key
                <input
                  type="text"
                  className="masked-input"
                  value={glmKey}
                  placeholder="粘贴你的 智谱清言 API Key"
                  onChange={(e) => saveGlmKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <p className="hint">给回复生成用的 智谱清言 Key</p>
            </>
          )}

          {replyProvider === "kimi" && provider !== "kimi" && (
            <>
              <label className="field">
                回复模型 - Kimi API Key
                <input
                  type="text"
                  className="masked-input"
                  value={kimiKey}
                  placeholder="粘贴你的 Kimi API Key"
                  onChange={(e) => saveKimiKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <p className="hint">给回复生成用的 Kimi Key</p>
            </>
          )}

          {provider === "openai" && (
            <>
              <label className="field">
                OpenAI API Key
                <input
                  type="text"
                  className="masked-input"
                  value={openaiKey}
                  placeholder="粘贴你的 OpenAI API Key"
                  onChange={(e) => saveOpenaiKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <label className="field">
                API 地址（Base URL）
                <input
                  type="text"
                  value={openaiUrl}
                  placeholder="https://api.openai.com/v1"
                  onChange={(e) => saveOpenaiUrl(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <label className="field">
                模型名称
                <input
                  type="text"
                  value={openaiModel}
                  placeholder="gpt-4o-mini"
                  onChange={(e) => saveOpenaiModel(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
            </>
          )}

          {provider === "hunyuan" && (
            <>
              <label className="field">
                混元 API Key
                <input
                  type="text"
                  className="masked-input"
                  value={hunyuanKey}
                  placeholder="粘贴你的腾讯混元 API Key"
                  onChange={(e) => saveHunyuanKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <p className="hint">
                需要去 console.cloud.tencent.com/hunyuan 申请 Key。
              </p>
            </>
          )}

          {provider === "qwen" && (
            <>
              <label className="field">
                通义千问 API Key
                <input
                  type="text"
                  className="masked-input"
                  value={qwenKey}
                  placeholder="粘贴你的通义千问 API Key"
                  onChange={(e) => saveQwenKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <p className="hint">
                需要去 dashscope.aliyuncs.com 申请 Key。
              </p>
            </>
          )}

          {provider === "glm" && (
            <>
              <label className="field">
                智谱 GLM API Key
                <input
                  type="text"
                  className="masked-input"
                  value={glmKey}
                  placeholder="粘贴你的智谱 API Key"
                  onChange={(e) => saveGlmKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <p className="hint">
                需要去 open.bigmodel.cn 申请 Key。
              </p>
            </>
          )}

          {provider === "kimi" && (
            <>
              <label className="field">
                Kimi API Key
                <input
                  type="text"
                  className="masked-input"
                  value={kimiKey}
                  placeholder="粘贴你的 Kimi API Key"
                  onChange={(e) => saveKimiKey(e.target.value)}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </label>
              <p className="hint">
                需要去 platform.moonshot.cn 申请 Key。
              </p>
            </>
          )}
          </div>
          <div className="settings-card">
          </div>

          {/* 主题设置卡片 */}
          <div className="settings-card">
            <h3>🎨 主题设置</h3>
            <label className="field">
              主题颜色
              <div style={{ display: "flex", gap: 12, marginTop: 12, alignItems: "center" }}>
                {[
                  { name: "樱花粉", color: "#ff6b9d" },
                  { name: "天空蓝", color: "#0a84ff" },
                  { name: "香芋紫", color: "#af52de" },
                  { name: "薄荷绿", color: "#30d158" },
                  { name: "活力橙", color: "#ff9500" },
                ].map((c) => (
                  <button
                    key={c.color}
                    onClick={() => {
                      setThemeColor(c.color);
                      localStorage.setItem("crush_theme_color", c.color);
                    }}
                    style={{
                      width: 36,
                      height: 36,
                      borderRadius: 18,
                      background: c.color,
                      border: themeColor === c.color ? "3px solid #333" : "2px solid #eee",
                      cursor: "pointer",
                    }}
                    title={c.name}
                  />
                ))}
                <button
                  className="secondary"
                  onClick={() => {
                    setThemeColor("#ff6b9d");
                    localStorage.setItem("crush_theme_color", "#ff6b9d");
                  }}
                  style={{ marginLeft: 8, fontSize: 13 }}
                >
                  恢复默认
                </button>
              </div>
            </label>

            <label className="field" style={{ marginTop: 16 }}>
              背景图片
              <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                <button
                  className="secondary"
                  onClick={() => bgInputRef.current?.click()}
                  style={{ flex: 1 }}
                >
                  上传背景图
                </button>
                {bgImage && (
                  <button
                    className="secondary"
                    onClick={() => {
                      setBgImage("");
                      localStorage.removeItem("crush_bg_image");
                    }}
                  >
                    清除
                  </button>
                )}
              </div>
              <input
                ref={bgInputRef}
                type="file"
                accept="image/*"
                style={{ display: "none" }}
                onChange={handleBgUpload}
              />
            </label>
          </div>

          {/* 运行日志卡片 */}
          <div className="settings-card">
            <h3>📜 运行日志</h3>
            <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
              <button
                className={!showErrorOnly ? "secondary active" : "secondary"}
                onClick={() => setShowErrorOnly(false)}
                style={{ flex: 1, fontSize: 13 }}
              >
                全部日志
              </button>
              <button
                className={showErrorOnly ? "secondary active" : "secondary"}
                onClick={() => setShowErrorOnly(true)}
                style={{ flex: 1, fontSize: 13 }}
              >
                仅错误
              </button>
              <button
                className="secondary"
                onClick={() => {
                  setLogs([]);
                  localStorage.removeItem("crush_logs");
                }}
                style={{ fontSize: 13 }}
              >
                清空
              </button>
            </div>
            <div style={{ maxHeight: 200, overflowY: "auto", fontSize: 12, lineHeight: 1.6 }}>
              {logs.length === 0 ? (
                <p className="hint">暂无日志</p>
              ) : (
                (showErrorOnly ? logs.filter(l => l.type === "error") : logs).map((log, i) => (
                  <div key={i} style={{
                    padding: "4px 0",
                    borderBottom: "1px solid #f0f0f0",
                    color: log.type === "error" ? "#ff3b30" : "#666",
                  }}>
                    <span style={{ color: "#999", marginRight: 8 }}>{log.time}</span>
                    <span style={{ fontWeight: log.type === "error" ? "bold" : "normal" }}>
                      [{log.type === "error" ? "错误" : "信息"}]
                    </span>
                    {log.message}
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="settings-card">
          <button
            className="secondary"
            disabled={!messages.length}
            onClick={() => {
              const ms = messages.map((m) => ({
                ...m,
                sender:
                  m.sender === "self" ? ("other" as const) : ("self" as const),
              }));
              setSelf(other);
              setOther(self === "__self_absent__" ? "我" : self);
              setMessages(ms);
              a.reset();
              a.run(ms, relation, background, knows, fantasyMode);
              setTab("chat");
            }}
          >
            交换双方身份
          </button>
          <button className="secondary danger" onClick={clear}>
            清空聊天，重新开始
          </button>
          <p>
            已保存 {messages.length.toLocaleString()}{" "}
            条聊天。记录保存在本机浏览器，刷新后可继续；分析时只发送所需片段给模型服务。清空会删除本机记录。
          </p>
          </div>
        </section>
      )}
      {showModelPicker && (
        <div className="ios-sheet-backdrop" onClick={() => setShowModelPicker(false)} style={{ zIndex: 2000 }}>
          <div className="ios-sheet" onClick={(e) => e.stopPropagation()} style={{ maxHeight: "70vh" }}>
            <div className="ios-sheet-title">选择分析模型</div>
            <div style={{ overflowY: "auto", maxHeight: "50vh" }}>
              {Object.entries(PROVIDER_CONFIG).map(([key, cfg]) => (
                <button
                  key={key}
                  className={`ios-sheet-option ${provider === key ? "selected" : ""}`}
                  onClick={() => {
                    changeProvider(key as Provider);
                    setShowModelPicker(false);
                  }}
                >
                  <div>
                    <div className="ios-sheet-option-name">{cfg.name}</div>
                    <div className="ios-sheet-option-desc">{cfg.desc}</div>
                  </div>
                  {provider === key && <span className="checkmark">✓</span>}
                </button>
              ))}
            </div>
            <button className="ios-sheet-cancel" onClick={() => setShowModelPicker(false)}>
              取消
            </button>
          </div>
        </div>
      )}

      {showReplyModelPicker && (
        <div className="ios-sheet-backdrop" onClick={() => setShowReplyModelPicker(false)} style={{ zIndex: 2000 }}>
          <div className="ios-sheet" onClick={(e) => e.stopPropagation()} style={{ maxHeight: "70vh" }}>
            <div className="ios-sheet-title">选择回复生成模型</div>
            <div style={{ overflowY: "auto", maxHeight: "50vh" }}>
              {Object.entries(PROVIDER_CONFIG).map(([key, cfg]) => (
                <button
                  key={key}
                  className={`ios-sheet-option ${replyProvider === key ? "selected" : ""}`}
                  onClick={() => {
                    changeReplyProvider(key as Provider);
                    setShowReplyModelPicker(false);
                  }}
                >
                  <div>
                    <div className="ios-sheet-option-name">{cfg.name}</div>
                    <div className="ios-sheet-option-desc">{cfg.desc}</div>
                  </div>
                  {replyProvider === key && <span className="checkmark">✓</span>}
                </button>
              ))}
            </div>
            <button className="ios-sheet-cancel" onClick={() => setShowReplyModelPicker(false)}>
              取消
            </button>
          </div>
        </div>
      )}

      {/* 人物设置弹窗 */}
      {showPersonSettings && (
        <div className="ios-sheet-backdrop" onClick={() => setShowPersonSettings(false)}>
          <div className="ios-sheet" onClick={(e) => e.stopPropagation()} style={{ maxHeight: "80vh" }}>
            <div className="ios-sheet-title">人物设置 - {other}</div>
            <div style={{ overflowY: "auto", maxHeight: "60vh", padding: "16px" }}>
              {/* 关系选择 */}
              <label className="field" style={{ marginBottom: 16 }}>
                你们的关系
                <div className="ios-segment">
                  {Object.entries(RELATIONS).map(([k, v]) => (
                    <button
                      key={k}
                      className={relation === k ? "active" : ""}
                      onClick={() => {
                        const r = k as Relation;
                        setRelation(r);
                        if (messages.length) a.run(messages, r, background, knows, fantasyMode);
                      }}
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </label>

              {/* 知情开关 */}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, padding: "8px 0" }}>
                <span>她知道你喜欢她吗？</span>
                <button
                  onClick={() => setKnows(prev => !prev)}
                  style={{
                    width: 48,
                    height: 28,
                    borderRadius: 14,
                    background: knows ? "#0a84ff" : "#e5e5ea",
                    border: "none",
                    position: "relative",
                    cursor: "pointer",
                    transition: "background 0.2s",
                  }}
                >
                  <span style={{
                    position: "absolute",
                    top: 2,
                    left: knows ? 22 : 2,
                    width: 24,
                    height: 24,
                    borderRadius: 12,
                    background: "white",
                    boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                    transition: "left 0.2s",
                  }} />
                </button>
              </div>

              {/* 幻想模式 */}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8, padding: "8px 0" }}>
                <span style={{ color: "#af52de" }}>✨ 幻想模式</span>
                <button
                  onClick={() => {
                    const newVal = !fantasyMode;
                    setFantasyMode(newVal);
                    // 开启/关闭后立即重新分析，确保生效
                    if (messages.length) {
                      setTimeout(() => {
                        a.run(messages, relation, background, knows, newVal);
                      }, 100);
                    }
                  }}
                  style={{
                    width: 48,
                    height: 28,
                    borderRadius: 14,
                    background: fantasyMode ? "#af52de" : "#e5e5ea",
                    border: "none",
                    position: "relative",
                    cursor: "pointer",
                    transition: "background 0.2s",
                  }}
                >
                  <span style={{
                    position: "absolute",
                    top: 2,
                    left: fantasyMode ? 22 : 2,
                    width: 24,
                    height: 24,
                    borderRadius: 12,
                    background: "white",
                    boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                    transition: "left 0.2s",
                  }} />
                </button>
              </div>
              <p className="hint" style={{ color: "#af52de", marginBottom: 16 }}>
                开启后好感度锁定100%，所有分析全部向好方向解读，纯娱乐用。
              </p>

              {/* 模型设置（每个人物独立） */}
              <label className="field" style={{ marginBottom: 12 }}>
                分析模型（这个人用的）
                <button
                  className="ios-picker-button"
                  onClick={() => setShowModelPicker(true)}
                  style={{ marginTop: 8 }}
                >
                  <span>{PROVIDER_CONFIG[provider].name}</span>
                  <span className="chevron">›</span>
                </button>
              </label>

              <label className="field" style={{ marginBottom: 16 }}>
                回复生成模型（这个人用的）
                <button
                  className="ios-picker-button"
                  onClick={() => setShowReplyModelPicker(true)}
                  style={{ marginTop: 8 }}
                >
                  <span>{PROVIDER_CONFIG[replyProvider].name}</span>
                  <span className="chevron">›</span>
                </button>
              </label>
              <p className="hint" style={{ marginBottom: 16 }}>
                每个人物可以用不同的模型，切换人物自动切换，不会互相影响。
              </p>

              {/* 人物背景板 */}
              <label className="field">
                人物背景信息（可选）
                <textarea
                  value={background}
                  onChange={(e) => setBackground(e.target.value)}
                  placeholder="比如：大学同学，性格内向，平时话不多，最近刚分手..."
                  style={{
                    minHeight: 100,
                    padding: 12,
                    borderRadius: 10,
                    border: "1px solid #ddd",
                    fontSize: 15,
                    resize: "vertical",
                    width: "100%",
                    boxSizing: "border-box",
                  }}
                />
                <p className="hint">
                  每个人单独存一份背景，AI分析时会参考这些信息，判断更准。
                </p>
              </label>
            </div>
            <button className="ios-sheet-cancel" onClick={() => setShowPersonSettings(false)}>
              完成
            </button>
          </div>
        </div>
      )}

      {/* 新建会话弹窗 */}
      {showNewConv && (
        <Modal title="新建聊天对象" close={() => setShowNewConv(false)}>
          <label className="field">
            对方昵称
            <input
              type="text"
              value={newConvName}
              placeholder="比如：骨、A、小美..."
              onChange={(e) => setNewConvName(e.target.value)}
              autoFocus
            />
          </label>
          <button
            className="primary"
            disabled={!newConvName.trim()}
            onClick={addConversation}
          >
            创建会话
          </button>
          <button className="secondary" onClick={() => setShowNewConv(false)}>
            取消
          </button>
        </Modal>
      )}

      {/* 会话长按菜单 */}
      {showConvMenu && multi && (
        <div className="ios-sheet-backdrop" onClick={() => setShowConvMenu(null)}>
          <div className="ios-sheet" onClick={(e) => e.stopPropagation()}>
            <div className="ios-sheet-title">
              {multi.conversations[showConvMenu]?.name}
            </div>
            <button
              className="ios-sheet-option danger"
              onClick={() => deleteConversation(showConvMenu)}
            >
              <div>
                <div className="ios-sheet-option-name">删除会话</div>
                <div className="ios-sheet-option-desc">
                  聊天记录和分析结果都会删除
                </div>
              </div>
            </button>
            <button className="ios-sheet-cancel" onClick={() => setShowConvMenu(null)}>
              取消
            </button>
          </div>
        </div>
      )}

      {detail === "clear" && (
        <Modal title="开始新的聊天？" close={() => setDetail(null)}>
          <p>当前聊天、分析和本机保存的记录都会删除。</p>
          <button className="primary" onClick={clear}>
            开始新聊天
          </button>
          <button className="secondary" onClick={() => setDetail(null)}>
            保留当前聊天
          </button>
        </Modal>
      )}
      {detail && detail !== "clear" && (
        <Modal
          title={
            detail === "overview"
              ? "好感度"
              : detail === "action"
                ? "下一步"
                : detail === "performance"
                  ? "我的发挥"
                  : chosen?.sender === "other"
                    ? "情绪与意图"
                    : "回复评价"
          }
          close={() => setDetail(null)}
        >
          {detail === "overview" ? (
            <>
              <p>
                0—100 是模型对这段聊天的好感信号评分，不是「对方喜欢你的概率」。
              </p>
              <p>
                根据近期对话和相关历史原话评分，旧分数不参与计算。证据少时仍保留分数供娱乐参考。
              </p>
              {!!ov?.memoryEvidenceIds?.length && (
                <details>
                  <summary>参考的历史原话</summary>
                  {[...new Set(ov.memoryEvidenceIds)].map((id) => {
                    const m = messages.find((m) => m.id === id);
                    return m ? (
                      <blockquote key={id}>
                        {m.sender === "self" ? self : other}：{m.text}
                      </blockquote>
                    ) : null;
                  })}
                </details>
              )}
              {ov?.affinityDimensions && (
                <div className="affinity-breakdown">
                  {ov.affinityDimensions.map((d) => (
                    <div key={d.key}>
                      <span>{d.label}</span>
                      <meter
                        min="0"
                        max="100"
                        value={d.judgment.value ?? 0}
                        aria-label={`${d.label} ${d.judgment.value} 分`}
                      />
                      <strong>{d.judgment.value}</strong>
                      <small>
                        占 {d.weight}% · {statusLabel(d.judgment)}
                      </small>
                    </div>
                  ))}
                </div>
              )}
              {ov?.boundaryApplied && (
                <p>
                  对方表达了明确且仍有效的拒绝边界。综合原分{" "}
                  {ov.affinityRawValue}，最终好感度最多显示 25 分。
                </p>
              )}
              {ov && (
                <p>
                  本轮判断：{statusLabel(ov.affinity)}。综合确定度{" "}
                  {Math.round(ov.affinity.confidence * 100)}%。
                </p>
              )}
            </>
          ) : detail === "action" ? (
            <>
              <h3>{ov ? ACTIONS[ov.action]?.label : "等待聊天"}</h3>
              <p>{ov ? ACTIONS[ov.action]?.detail : "导入后生成建议。"}</p>
              {ov?.actionEvidenceId && (
                <blockquote>
                  {messages.find((m) => m.id === ov.actionEvidenceId)?.text}
                </blockquote>
              )}
            </>
          ) : detail === "performance" ? (
            <>
              <div className="detail-score">
                {quality ?? "—"}
                <span>/100</span>
              </div>
              <p>
                已完成分析的我方回复平均分。Jev
                根据发出时的前文评价表达质量，再按固定分数区间显示评级。
              </p>
              <div className="reply-guide">
                {REPLY_RATINGS.map((v) => (
                  <p key={v.label}>
                    <strong>
                      {v.label} · {v.range} 分
                    </strong>
                    ：{v.description}
                  </p>
                ))}
              </div>
            </>
          ) : (
            <>
              <blockquote>{chosen?.text}</blockquote>
              {chosen?.sender === "other" ? (
                <>
                  <h3>情绪</h3>
                  <div className="emotion-distribution">
                    {Object.entries(result?.emotions || {})
                      .sort((a, b) => b[1] - a[1])
                      .map(([key, p]) => (
                        <div key={key}>
                          <span>
                            {EMOTIONS[key as keyof typeof EMOTIONS]?.label ||
                              key}
                          </span>
                          <div className="probability-track">
                            <i style={{ width: `${p * 100}%` }} />
                          </div>
                          <b>
                            {p > 0 && p < 0.005
                              ? "<1%"
                              : `${Math.round(p * 100)}%`}
                          </b>
                        </div>
                      ))}
                  </div>
                  <h3 className="intent-detail-heading">意图</h3>
                  <div className="intent-distribution">
                    {Object.entries(result?.intents || {})
                      .filter(([key, p]) => key in INTENTS && p > 0)
                      .sort((a, b) => b[1] - a[1])
                      .map(([key, p]) => (
                        <div key={key} className="intent-detail-item">
                          <div>
                            <strong>
                              {INTENTS[key as keyof typeof INTENTS].label}
                            </strong>
                            <b>
                              {p < 0.005 ? "<1%" : `${Math.round(p * 100)}%`}
                            </b>
                          </div>
                          <p>{INTENTS[key as keyof typeof INTENTS].criteria}</p>
                        </div>
                      ))}
                    {!result?.intents && <p>意图尚未分析。</p>}
                  </div>
                  <p>
                    两行分别展示主要情绪与主要沟通意图的候选解读，不代表测量真实内心。每行最多显示前三项，保留原始概率，不重新凑成
                    100%。
                  </p>
                </>
              ) : (
                <>
                  <h3 className="reply-verdict">
                    回复评级：
                    {replyRating(result?.score.value)?.label ?? "待判断"}
                  </h3>
                  <p>
                    {replyRating(result?.score.value)?.description ??
                      "当前语境不足以判断表达质量"}
                  </p>
                  <p>
                    回复评分 {result?.score.value ?? "—"} / 100 ·{" "}
                    {result && statusLabel(result.score)}
                  </p>
                </>
              )}
              <p>结合当前已导入的上下文判断，不代表对方真实想法。</p>
            </>
          )}
        </Modal>
      )}
      {overlap && (
        <Modal title="这段可能重复了" close={() => setOverlap(null)}>
          <p>相同内容也可能是新消息，请选择如何合并。</p>
          <button
            className="primary"
            onClick={() => {
              add(overlap, "skip");
              setOverlap(null);
            }}
          >
            跳过重合部分
          </button>
          <button
            className="secondary"
            onClick={() => {
              add(overlap, "append");
              setOverlap(null);
            }}
          >
            作为新消息追加
          </button>
        </Modal>
      )}

      {/* 推荐回复弹窗 */}
      {showReplies && (
        <Modal title="推荐回复" close={() => setShowReplies(false)}>
          {/* 选择读取多少条近期消息 */}
          <div style={{ marginBottom: 12 }}>
            <span style={{ fontSize: 13, color: "#666", marginRight: 8 }}>读取最近：</span>
            {[10, 20, 30, 50].map((n) => (
              <button
                key={n}
                onClick={() => setRecentCount(n)}
                style={{
                  padding: "4px 10px",
                  margin: "0 4px",
                  fontSize: 12,
                  borderRadius: 12,
                  border: "1px solid #ddd",
                  background: recentCount === n ? "#0a84ff" : "white",
                  color: recentCount === n ? "white" : "#333",
                  cursor: "pointer",
                }}
              >
                {n}条
              </button>
            ))}
          </div>

          {/* 三条推荐回复 */}
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {replies.map((reply, i) => (
              <div
                key={i}
                style={{
                  padding: 12,
                  background: "#f9f9fb",
                  borderRadius: 12,
                  border: "1px solid #eee",
                }}
              >
                <p style={{ margin: "0 0 8px 0", fontSize: 14, lineHeight: 1.5 }}>{reply}</p>
                <button
                  onClick={() => copyReply(reply)}
                  style={{
                    fontSize: 12,
                    padding: "4px 12px",
                    borderRadius: 12,
                    border: "1px solid #0a84ff",
                    background: "white",
                    color: "#0a84ff",
                    cursor: "pointer",
                  }}
                >
                  复制
                </button>
              </div>
            ))}
          </div>

          {/* 重新生成按钮 */}
          <button
            className="secondary"
            style={{ marginTop: 12, width: "100%" }}
            onClick={handleGenerateReplies}
            disabled={repliesLoading}
          >
            {repliesLoading ? "生成中..." : "重新生成"}
          </button>
        </Modal>
      )}
      {/* 底部 Tab 导航栏 */}
      <nav className="ios-tabbar" aria-label="底部导航">
        <button
          className={tab === "chat" ? "active" : ""}
          onClick={() => setTab("chat")}
        >
          <MessageCircle size={22} />
          <span>聊天</span>
        </button>
        <button
          className={tab === "settings" ? "active" : ""}
          onClick={() => setTab("settings")}
        >
          <Settings2 size={22} />
          <span>设置</span>
        </button>
      </nav>

      {/* 首次启动欢迎弹窗 */}
      {showWelcome && (
        <div style={{
          position: "fixed",
          inset: 0,
          background: "rgba(0,0,0,0.5)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 9999,
          padding: 24,
        }}>
          <div style={{
            background: "white",
            borderRadius: 24,
            padding: 28,
            maxWidth: 400,
            width: "100%",
            boxShadow: "0 20px 60px rgba(0,0,0,0.3)",
          }}>
            <h2 style={{ textAlign: "center", marginTop: 0, marginBottom: 20, fontSize: 22, fontWeight: 700 }}>
              🍯 Crush好感监控器
            </h2>
            <div style={{ fontSize: 14, lineHeight: 1.8, color: "#333", marginBottom: 24 }}>
              <p style={{ margin: "0 0 8px 0" }}>本项目原作者 @劈个茄子</p>
              <p style={{ margin: "0 0 8px 0", color: "#666", fontSize: 13 }}>
                GitHub 仓库：FerryCorleone/crush-monitor
              </p>
              <p style={{ margin: "16px 0 8px 0", fontWeight: 500 }}>
                安卓编译魔改版作者 @番茄看海
              </p>
              <p style={{ margin: "0 0 8px 0", color: "#666", fontSize: 13 }}>
                GitHub 搜索 FQKH/Crush-，下载 apk 文件打开即可
              </p>
              <p style={{ margin: "16px 0 8px 0", color: "#ff6b9d", fontWeight: 500 }}>
                ⚠️ 本项目纯公益开源，切勿相信任何收费
              </p>
              <p style={{ margin: "8px 0 0 0", color: "#999", fontSize: 13, textAlign: "center" }}>
                项目不保证他能绝对爱你 💔
              </p>
            </div>
            <button
              onClick={closeWelcome}
              disabled={countdown > 0}
              style={{
                width: "100%",
                height: 48,
                borderRadius: 24,
                border: "none",
                background: countdown > 0 ? "#e5e5ea" : "var(--theme-color, #ff6b9d)",
                color: countdown > 0 ? "#999" : "white",
                fontSize: 16,
                fontWeight: 600,
                cursor: countdown > 0 ? "not-allowed" : "pointer",
              }}
            >
              {countdown > 0 ? `请阅读 ${countdown} 秒` : "我知道了"}
            </button>
          </div>
        </div>
      )}
    </main>
  );
}
