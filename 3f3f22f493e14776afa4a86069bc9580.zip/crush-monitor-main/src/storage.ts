import type { Message, Relation, LineResult, Overview } from "../shared/types";
import type { MemoryEvent } from "../shared/memory";

export type Trend = { at: string; value: number | null; count: number };

/** 兼容旧版restore接口的会话数据类型 */
export type SavedConversation = {
  schema: 1;
  rubric: string;
  messages: Message[];
  self: string;
  other: string;
  relation: Relation;
  background?: string;
  knowsYourFeelings?: boolean;
  fantasyMode?: boolean;
  lines: Record<string, LineResult>;
  events: Record<string, MemoryEvent>;
  overview: Overview | null;
  trend: Trend[];
  analyzedCount: number;
  completed: boolean;
};

/** 单个会话的完整数据 */
export type Conversation = {
  id: string;
  name: string;          // 对方昵称，如"骨"、"A"
  createdAt: number;
  rubric: string;
  messages: Message[];
  self: string;
  other: string;
  relation: Relation;
  background: string;    // 人物背景信息（可选）
  knowsYourFeelings: boolean; // 对方是否知道你喜欢她
  fantasyMode: boolean;  // 幻想模式：好感度锁定100%，分析全部向好
  analysisProvider?: string;  // 这个人物单独用的分析模型（可选，没有就用全局默认）
  replyProvider?: string;    // 这个人物单独用的回复模型（可选）
  lines: Record<string, LineResult>;
  events: Record<string, MemoryEvent>;
  overview: Overview | null;
  trend: Trend[];
  analyzedCount: number;
  completed: boolean;
};

/** 多会话存储结构 */
export type MultiConversations = {
  schema: 2;
  activeId: string;      // 当前激活的会话ID
  conversations: Record<string, Conversation>;
};

let connection: Promise<IDBDatabase> | undefined;

function db() {
  return (connection ??= new Promise<IDBDatabase>((resolve, reject) => {
    const req = indexedDB.open("crush-monitor", 2);
    req.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains("workspace")) {
        db.createObjectStore("workspace");
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => {
      connection = undefined;
      reject(req.error);
    };
  }));
}

/** 生成唯一会话ID */
export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

/** 创建一个新的空会话 */
export function createConversation(name: string, relation: Relation): Conversation {
  return {
    id: generateId(),
    name,
    createdAt: Date.now(),
    rubric: "",
    messages: [],
    self: "",
    other: name,
    relation,
    background: "",
    knowsYourFeelings: false,
    fantasyMode: false,
    lines: {},
    events: {},
    overview: null,
    trend: [],
    analyzedCount: 0,
    completed: false,
  };
}

/** 加载所有会话 */
export async function loadConversations(): Promise<MultiConversations> {
  const database = await db();
  return new Promise((resolve, reject) => {
    const tx = database.transaction("workspace", "readonly");
    const store = tx.objectStore("workspace");

    // 先尝试读新格式的多会话数据
    const req = store.get("multi");
    req.onsuccess = () => {
      if (req.result) {
        resolve(req.result as MultiConversations);
        return;
      }
      // 没有新数据，尝试读旧格式做迁移
      const oldReq = store.get("current");
      oldReq.onsuccess = () => {
        if (oldReq.result) {
          // 迁移旧数据到新格式
          const old = oldReq.result as any;
          const conv = createConversation(old.other || "Crush", old.relation || "crush");
          conv.rubric = old.rubric || "";
          conv.messages = old.messages || [];
          conv.self = old.self || "";
          conv.other = old.other || "Crush";
          conv.relation = old.relation || "crush";
          conv.lines = old.lines || {};
          conv.events = old.events || {};
          conv.overview = old.overview || null;
          conv.trend = old.trend || [];
          conv.analyzedCount = old.analyzedCount || 0;
          conv.completed = old.completed || false;
          resolve({
            schema: 2,
            activeId: conv.id,
            conversations: { [conv.id]: conv },
          });
        } else {
          // 完全没有数据，创建一个默认会话
          const conv = createConversation("Crush", "crush");
          resolve({
            schema: 2,
            activeId: conv.id,
            conversations: { [conv.id]: conv },
          });
        }
      };
      oldReq.onerror = () => reject(oldReq.error);
    };
    req.onerror = () => reject(req.error);
  });
}

/** 保存所有会话 */
export async function saveConversations(data: MultiConversations): Promise<void> {
  const database = await db();
  return new Promise((resolve, reject) => {
    const tx = database.transaction("workspace", "readwrite");
    const store = tx.objectStore("workspace");
    store.put(data, "multi");
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error ?? new Error("保存被中断"));
  });
}
