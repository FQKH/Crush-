import { parseChat } from "./shared/parser.ts";

const testText = `·番茄看海
2026年09月23日 17:54
我点了一下扫码，直接微信卡崩了

·骨骼
2026年09月23日 17:54
我手机没电

·骨骼
2026年09月23日 17:54
wdfk

·番茄看海
2026年09月23日 17:54
你别跟别的男孩子加微信，我到时候随机抽查给你打电话`;

const result = parseChat(testText);
console.log("解析出消息数:", result.messages.length);
console.log("警告:", result.warnings);
result.messages.forEach((m, i) => {
  console.log(`\n消息${i+1}:`);
  console.log("  说话人:", m.speaker);
  console.log("  时间:", m.timestamp);
  console.log("  内容:", m.text);
});
