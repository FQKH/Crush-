import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "/usr/local/bin/chromium", args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 420, height: 860 } });
await page.goto("http://127.0.0.1:4176/", { waitUntil: "networkidle" });
await page.waitForTimeout(400);

// 1. 导入示例
await page.evaluate(() => [...document.querySelectorAll("button")].find(b => b.textContent?.includes("用一段示例试试"))?.click());
await page.waitForTimeout(500);
await page.screenshot({ path: "/tmp/v15-import.png", fullPage: true });

// 2. 点"开始分析"确认导入，然后检查消息布局
await page.evaluate(() => [...document.querySelectorAll("button")].find(b => b.textContent?.includes("开始分析"))?.click());
await page.waitForTimeout(600);

// 检查消息是否重叠：取前4条消息的 boundingBox
const boxes = await page.evaluate(() => {
  const msgs = [...document.querySelectorAll(".message")].slice(0, 5);
  return msgs.map((m, i) => {
    const r = m.getBoundingClientRect();
    return { i, top: Math.round(r.top), bottom: Math.round(r.bottom), h: Math.round(r.height) };
  });
});
console.log("消息位置:", JSON.stringify(boxes, null, 1));
// 检测重叠：后一条 top < 前一条 bottom - 2
let overlap = false;
for (let i = 1; i < boxes.length; i++) {
  if (boxes[i].top < boxes[i - 1].bottom - 2) { overlap = true; console.log("重叠!", i); }
}
console.log("重叠:", overlap);

// 3. 检查底部 Tab 栏
const tabbar = await page.evaluate(() => {
  const tb = document.querySelector(".ios-tabbar");
  return tb ? { buttons: tb.querySelectorAll("button").length, text: tb.textContent } : null;
});
console.log("底部Tab栏:", JSON.stringify(tabbar));

// 4. 点设置 Tab，检查设置面板
await page.evaluate(() => {
  const btns = [...document.querySelectorAll(".ios-tabbar button")];
  btns.find(b => b.textContent?.includes("设置"))?.click();
});
await page.waitForTimeout(500);
const settingsSheet = await page.evaluate(() => {
  const s = document.querySelector(".settings-sheet");
  const seg = document.querySelector(".ios-segment");
  return {
    hasSheet: !!s,
    sheetRect: s ? { top: Math.round(s.getBoundingClientRect().top), bottom: Math.round(s.getBoundingClientRect().bottom) } : null,
    hasSegment: !!seg,
    segmentText: seg ? seg.textContent : null,
  };
});
console.log("设置面板:", JSON.stringify(settingsSheet));
await page.screenshot({ path: "/tmp/v15-settings.png", fullPage: true });
await browser.close();
