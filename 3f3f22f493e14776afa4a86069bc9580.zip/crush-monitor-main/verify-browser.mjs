import { chromium } from "playwright-core";

const browser = await chromium.launch({
  executablePath: "/usr/local/bin/chromium",
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const page = await browser.newPage({ viewport: { width: 420, height: 800 } });
const errors = [];
page.on("pageerror", (e) => errors.push("页面错误: " + e.message));
page.on("console", (m) => {
  if (m.type() === "error") errors.push("控制台错误: " + m.text());
});

await page.goto("http://127.0.0.1:4173/", { waitUntil: "networkidle" });
await page.waitForTimeout(600);
console.log("标题:", await page.title());

// 1) 强制打开设置弹窗
await page.evaluate(() => {
  document.querySelector(".rail-settings")?.click();
});
await page.waitForTimeout(500);
await page.screenshot({ path: "/tmp/crush-settings.png" });

// 2) 填 Key 并验证保存
const keyInput = await page.$('input[type="password"]');
console.log("API Key 输入框存在:", !!keyInput);
if (keyInput) {
  await keyInput.fill("sk-test-123456");
  await page.waitForTimeout(300);
  console.log(
    "localStorage 保存:",
    await page.evaluate(() => localStorage.getItem("crush_typesafe_api_key")),
  );
}
// 关闭设置
await page.evaluate(() => document.querySelector(".modal button[aria-label]")?.click());
await page.waitForTimeout(300);

// 3) 用示例导入聊天
await page.evaluate(() => {
  const btns = [...document.querySelectorAll("button")];
  btns.find((b) => b.textContent?.includes("用一段示例试试"))?.click();
});
await page.waitForTimeout(800);
await page.screenshot({ path: "/tmp/crush-example.png" });

// 4) 点击"开始分析"（确认导入弹窗里的主按钮）
const confirmBtn = await page.$(".modal button.primary");
console.log("导入确认按钮存在:", !!confirmBtn);
if (confirmBtn) {
  await confirmBtn.click();
  await page.waitForTimeout(3000);
  await page.screenshot({ path: "/tmp/crush-analyze.png" });
}

// 5) 检查页面上的错误/提示文本
const bodyText = await page.evaluate(() => document.body.innerText);
const hasKeyError = bodyText.includes("请先在");
console.log("无Key时是否提示填写Key:", hasKeyError);

// 6) 刷新后 Key 回显验证
await page.reload({ waitUntil: "networkidle" });
await page.waitForTimeout(500);
await page.evaluate(() => document.querySelector(".rail-settings")?.click());
await page.waitForTimeout(400);
const restored = await page.evaluate(
  () => document.querySelector('input[type="password"]')?.value,
);
console.log("刷新后 Key 回显:", restored);

console.log("JS 错误:", errors.length ? errors : "无");
await browser.close();
