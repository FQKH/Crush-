import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "/usr/local/bin/chromium", args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 420, height: 800 } });
await page.goto("http://127.0.0.1:4174/", { waitUntil: "networkidle" });
await page.waitForTimeout(500);
// 打开设置
await page.evaluate(() => document.querySelector(".rail-settings")?.click());
await page.waitForTimeout(400);
// 检查模型选择下拉
const select = await page.$('select');
console.log("模型选择下拉存在:", !!select);
// 检查当前选项
const options = await page.$$eval('select option', ops => ops.map(o => o.textContent));
console.log("模型选项:", options);
// 切换到 deepseek
await page.selectOption('select', 'deepseek');
await page.waitForTimeout(300);
// 检查 DeepSeek Key 输入框
const dsInput = await page.$('input[type="password"]');
console.log("DeepSeek Key 输入框存在:", !!dsInput);
await page.screenshot({ path: "/tmp/settings-deepseek.png" });
// 切回 jev
await page.selectOption('select', 'jev');
await page.waitForTimeout(300);
await page.screenshot({ path: "/tmp/settings-jev.png" });
await browser.close();
